import queue as q
import math
import copy
class game:
	def __init__(self):
		self.n=0			# size of board
		self.initial_state = []		# initial game state
		self.final_state = []		# final game state
		self.visited = set()
		self.st = q.PriorityQueue()	# to store the cost for current configuration
		self.num_pos = {}		# to store the i,j, values for numbers
		self.trace_game = {}		# to store the track of configuration
		print("Enter the size of the board")
		self.n=int(input())
		print("Enter initial state of the board")
		for i in range(self.n):
			l = list(map(int,input().split(" ")))
			self.initial_state.append(l)
		print("Enter final state of the board")
		for i in range(self.n):
			l = list(map(int,input().split(" ")))
			self.final_state.append(l)
		for i in range(self.n):		# store the positions of numbers in final states
			for j in range(self.n):
				self.num_pos[self.final_state[i][j]] = (i,j)

	def isvalid(self,i,j):			# to check if the position is valid
		if i<0 or i>=self.n or j<0 or j>=self.n:
			return False
		return True

	@staticmethod				# print game board 
	def print_grid(board):
		for i in board:
			for j in i:
				print(j,end=" ")
			print()

	@staticmethod
	def zero_pos(board):			# get the position of 0
		for i in range(len(board)):
			for j in range(len(board)):
				if board[i][j]==0:
					return (i,j)

	def move_generator(self,board):		# generate all possible moves from current position 
		moves = []
		for i in range(self.n):
			for j in range(self.n):
				if board[i][j]==0:
					if self.isvalid(i-1,j):
						moves.append((i-1,j))
					if self.isvalid(i+1,j):
						moves.append((i+1,j))
					if self.isvalid(i,j-1):
						moves.append((i,j-1))
					if self.isvalid(i,j+1):
						moves.append((i,j+1))
		return moves

	def heuristic(self,game_state):		# calculate the heuristic cost : using Manhatan distance 
		cost = 0
		for i in range(self.n):
			for j in range(self.n):
				pos = self.num_pos[game_state[i][j]]
				cost+=(abs(i-pos[0])+abs(j-pos[1]))
		return cost


	@staticmethod				# function to convert tuple to list
	def tuple_for_list(board):
		tuple_of_tuple = tuple(tuple(i) for i in board)
		return tuple_of_tuple

	@staticmethod
	def list_for_tuple(board):		# function to convert list to tuple
		list_of_list = [list(i) for i in board]
		return list_of_list		

	def game_play(self):
		iterations = 0
		self.st.put(((0,0),game.tuple_for_list(self.initial_state)))	# insert the initial list in queue

		# set track game by initial values
		self.trace_game[game.tuple_for_list(self.initial_state)] = game.tuple_for_list(self.initial_state)
	
		while self.st.qsize()>0:
			current_node = self.st.get()				# get the value of node in top of queue
			board = game.list_for_tuple(current_node[1])
			if game.tuple_for_list(board) in self.visited:
				continue
			self.visited.add(game.tuple_for_list(board))
			if board==self.final_state:
				print("Moves required : "+str(current_node[0][1]))
				return
			moves = self.move_generator(board)
			pos_zero = game.zero_pos(board)
			for i in moves:
				duplicate = copy.deepcopy(board)
				temp = duplicate[pos_zero[0]][pos_zero[1]]
				duplicate[pos_zero[0]][pos_zero[1]] = duplicate[i[0]][i[1]]
				duplicate[i[0]][i[1]] = temp
				if game.tuple_for_list(duplicate) not in self.visited:
					ht = current_node[0][1]
					self.trace_game[game.tuple_for_list(duplicate)] = game.tuple_for_list(board)
					self.st.put(((ht+1+self.heuristic(duplicate),ht+1),game.tuple_for_list(duplicate)))
			iterations+=1
			if iterations>10**6:
				print("Probably not solvalbe")
				return 

	def print_move_sequence(self):
		move_sequence = []
		cur = game.tuple_for_list(self.final_state)
		while cur!=self.trace_game[cur]:
			move_sequence.append(cur)
			cur = self.trace_game[cur]
		move_sequence.append(self.initial_state)
		move_sequence.reverse()
		for i in move_sequence:
			game.print_grid(i)
			print()

khelo = game()
khelo.game_play()
khelo.print_move_sequence()



